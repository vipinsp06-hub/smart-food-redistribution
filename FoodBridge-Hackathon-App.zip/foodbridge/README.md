# FoodBridge — Smart Food Redistribution

A responsive web + Android-ready full-stack hackathon prototype based on the uploaded Smart Food Redistribution proposal.

## What is included
- Role-based demo workspaces: event donor, NGO, volunteer.
- Food donation creation with servings, pickup location, prepared time, best-before time and handling notes.
- NGO requirement creation.
- Transparent rule-based smart matching: district (45 points), food category (25), serving fit (20), freshness window (10).
- Pickup task assignment and status progression: Accepted → Picked up → Delivered.
- Dashboard and impact counts based on actual prototype records.
- Responsive PWA shell and Capacitor Android wrapper configuration.
- Flask + SQLite API with seeded Coimbatore/Tiruppur demo data.

## Requirements
- Python 3.10+
- Node.js 18+
- Android Studio only if building the Android APK

## Run locally

### 1. Start backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
API: http://localhost:5000/api/health

### 2. Start frontend (new terminal)
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173. Choose one of the demo workspaces. No password is needed in this prototype.

If your backend runs on another address, create `frontend/.env` with:
```env
VITE_API_URL=http://localhost:5000/api
```

## Android build (Capacitor)
The same React interface is configured for an Android WebView wrapper. After the frontend works:
```bash
cd frontend
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
Build/run the app from Android Studio. For a physical Android phone, set `VITE_API_URL` to your computer's LAN IP (for example `http://192.168.1.10:5000/api`) before building, and make sure phone and computer are on the same network. Do not use `localhost` for the phone's backend URL.

## Important prototype limitations
- Demo role selection is not secure authentication. Add Firebase/Auth0/OIDC and server-side role authorization before real deployment.
- The matching engine is an explainable heuristic, not a trained AI model. It does not claim to certify food safety.
- GPS tracking, push notifications, temperature sensors, identity/NGO verification, maps routing and live messaging are integration points for a production version; current prototype stores pickup addresses and task statuses.
- Food safety requires local policy, trained handling, temperature controls and human assessment. A best-before timer alone cannot determine whether food is safe.
- Seed/demo data and impact values are illustrative. Dashboard meal counts include only servings on tasks confirmed Delivered.

## Main API endpoints
`GET /api/health`, `GET /api/users`, `GET/POST /api/donations`, `GET/POST /api/requests`, `GET /api/matches`, `GET/POST /api/tasks`, `PATCH /api/tasks/:id`, `GET /api/dashboard`.
