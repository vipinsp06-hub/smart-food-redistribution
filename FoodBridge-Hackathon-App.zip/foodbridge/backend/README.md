# FoodBridge API

Python Flask + SQLite prototype API.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

API runs at http://localhost:5000. SQLite database and sample Coimbatore/Tiruppur data are created automatically.
