from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3, os, uuid
from datetime import datetime, timedelta

BASE = os.path.dirname(__file__)
DB = os.path.join(BASE, 'foodbridge.db')
app = Flask(__name__)
CORS(app)

SCHEMA = '''
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, name TEXT, email TEXT UNIQUE, role TEXT, organization TEXT, location TEXT, verified INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS donations(id TEXT PRIMARY KEY, donor_id TEXT, food_name TEXT, category TEXT, quantity INTEGER, unit TEXT, servings INTEGER, prepared_at TEXT, best_before TEXT, pickup_address TEXT, district TEXT, notes TEXT, status TEXT DEFAULT 'Available', created_at TEXT);
CREATE TABLE IF NOT EXISTS requests(id TEXT PRIMARY KEY, ngo_id TEXT, food_category TEXT, servings_needed INTEGER, district TEXT, needed_by TEXT, notes TEXT, status TEXT DEFAULT 'Open');
CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY, donation_id TEXT, volunteer_id TEXT, ngo_id TEXT, status TEXT DEFAULT 'Accepted', pickup_time TEXT, delivered_at TEXT);
'''
def db():
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row; return con

def init():
    con=db(); con.executescript(SCHEMA)
    if con.execute('SELECT COUNT(*) FROM users').fetchone()[0] == 0:
        users=[('u1','Ananya Events','ananya@example.com','donor','Ananya Catering','Coimbatore',1),('u2','Hope Community Trust','hope@example.com','ngo','Hope Community Trust','Coimbatore',1),('u3','Arun Volunteer','arun@example.com','volunteer','Community Volunteer','Coimbatore',1),('u4','City Food Network','city@example.com','ngo','City Food Network','Tiruppur',1)]
        con.executemany('INSERT INTO users VALUES(?,?,?,?,?,?,?)',users)
        now=datetime.now(); soon=now+timedelta(hours=5)
        con.execute('INSERT INTO donations VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',('d1','u1','Vegetable rice','Prepared meal',80,'meal',80,now.isoformat(timespec='minutes'),soon.isoformat(timespec='minutes'),'Race Course, Coimbatore','Coimbatore','Packed in sealed food-grade containers','Available',now.isoformat(timespec='minutes')))
        con.execute('INSERT INTO donations VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',('d2','u1','Idli and sambar','Prepared meal',120,'meal',120,now.isoformat(timespec='minutes'),(now+timedelta(hours=7)).isoformat(timespec='minutes'),'Peelamedu, Coimbatore','Coimbatore','Vegetarian breakfast packs','Available',now.isoformat(timespec='minutes')))
        con.execute('INSERT INTO requests VALUES(?,?,?,?,?,?,?,?)',('r1','u2','Prepared meal',100,'Coimbatore',(now+timedelta(hours=4)).isoformat(timespec='minutes'),'Dinner for residents','Open'))
        con.execute('INSERT INTO requests VALUES(?,?,?,?,?,?,?,?)',('r2','u4','Prepared meal',60,'Tiruppur',(now+timedelta(hours=6)).isoformat(timespec='minutes'),'Meals for evening distribution','Open'))
    con.commit(); con.close()

def rows(sql,args=()):
    con=db(); out=[dict(r) for r in con.execute(sql,args).fetchall()]; con.close(); return out

def row(sql,args=()):
    data=rows(sql,args); return data[0] if data else None

@app.get('/api/health')
def health(): return jsonify(status='ok', app='FoodBridge API')

@app.get('/api/users')
def users(): return jsonify(rows('SELECT * FROM users ORDER BY role,name'))

@app.post('/api/donations')
def create_donation():
    d=request.get_json(force=True); required=['donor_id','food_name','quantity','servings','best_before','pickup_address','district']
    if any(not d.get(k) for k in required): return jsonify(error='Please complete all required fields.'),400
    did='d'+uuid.uuid4().hex[:8]; now=datetime.now().isoformat(timespec='minutes')
    con=db(); con.execute('INSERT INTO donations VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(did,d['donor_id'],d['food_name'],d.get('category','Prepared meal'),int(d['quantity']),d.get('unit','meal'),int(d['servings']),d.get('prepared_at',now),d['best_before'],d['pickup_address'],d['district'],d.get('notes',''),'Available',now)); con.commit(); con.close()
    return jsonify(row('SELECT * FROM donations WHERE id=?',(did,))),201

@app.get('/api/donations')
def donations():
    status=request.args.get('status'); sql='SELECT d.*,u.name donor_name FROM donations d LEFT JOIN users u ON u.id=d.donor_id'; args=()
    if status: sql+=' WHERE d.status=?'; args=(status,)
    return jsonify(rows(sql+' ORDER BY d.created_at DESC',args))

@app.post('/api/requests')
def create_request():
    d=request.get_json(force=True); rid='r'+uuid.uuid4().hex[:8]
    con=db(); con.execute('INSERT INTO requests VALUES(?,?,?,?,?,?,?,?)',(rid,d.get('ngo_id','u2'),d.get('food_category','Any'),int(d.get('servings_needed',0)),d.get('district','Coimbatore'),d.get('needed_by',''),d.get('notes',''),'Open')); con.commit(); con.close()
    return jsonify(row('SELECT * FROM requests WHERE id=?',(rid,))),201

@app.get('/api/requests')
def requests(): return jsonify(rows('SELECT r.*,u.name ngo_name FROM requests r LEFT JOIN users u ON u.id=r.ngo_id ORDER BY r.status,r.needed_by'))

@app.get('/api/matches')
def matches():
    # Transparent prototype scoring: district match + category match + servings fit + freshness window.
    donations=rows("SELECT * FROM donations WHERE status='Available'")
    needs=rows("SELECT * FROM requests WHERE status='Open'")
    result=[]
    for d in donations:
        for n in needs:
            score=0; reasons=[]
            if d['district'].strip().lower()==n['district'].strip().lower(): score+=45; reasons.append('Same district')
            if n['food_category'].lower() in ('any',d['category'].lower(),'prepared meal'): score+=25; reasons.append('Food category fits')
            if d['servings']>=n['servings_needed']: score+=20; reasons.append('Enough servings')
            try:
                hours=(datetime.fromisoformat(d['best_before'])-datetime.now()).total_seconds()/3600
                if hours>0: score+=10; reasons.append('Within freshness window')
                else: score=0
            except: pass
            if score>=45: result.append({'donation':d,'request':n,'score':score,'reasons':reasons})
    return jsonify(sorted(result,key=lambda x:x['score'],reverse=True))

@app.post('/api/tasks')
def create_task():
    d=request.get_json(force=True); donation=row('SELECT * FROM donations WHERE id=?',(d.get('donation_id'),))
    if not donation: return jsonify(error='Donation not found'),404
    if donation['status']!='Available': return jsonify(error='Donation is no longer available'),409
    tid='t'+uuid.uuid4().hex[:8]; con=db(); con.execute('INSERT INTO tasks VALUES(?,?,?,?,?,?,?)',(tid,donation['id'],d.get('volunteer_id','u3'),d.get('ngo_id','u2'),'Accepted',datetime.now().isoformat(timespec='minutes'),None)); con.execute("UPDATE donations SET status='Reserved' WHERE id=?",(donation['id'],)); con.commit(); con.close()
    return jsonify(row('SELECT * FROM tasks WHERE id=?',(tid,))),201

@app.get('/api/tasks')
def tasks(): return jsonify(rows('SELECT t.*,d.food_name,d.servings,d.pickup_address,d.district,u.name volunteer_name FROM tasks t LEFT JOIN donations d ON d.id=t.donation_id LEFT JOIN users u ON u.id=t.volunteer_id ORDER BY t.pickup_time DESC'))

@app.patch('/api/tasks/<task_id>')
def update_task(task_id):
    status=request.get_json(force=True).get('status'); allowed=['Accepted','Picked up','Delivered']
    if status not in allowed: return jsonify(error='Invalid task status'),400
    con=db(); task=con.execute('SELECT * FROM tasks WHERE id=?',(task_id,)).fetchone()
    if not task: con.close(); return jsonify(error='Task not found'),404
    delivered=datetime.now().isoformat(timespec='minutes') if status=='Delivered' else None
    con.execute('UPDATE tasks SET status=?,delivered_at=COALESCE(?,delivered_at) WHERE id=?',(status,delivered,task_id))
    if status=='Delivered': con.execute("UPDATE donations SET status='Delivered' WHERE id=?",(task['donation_id'],))
    con.commit(); con.close(); return jsonify(row('SELECT * FROM tasks WHERE id=?',(task_id,)))

@app.get('/api/dashboard')
def dashboard():
    con=db(); q=lambda s: con.execute(s).fetchone()[0]
    data={'donations':q('SELECT COUNT(*) FROM donations'),'available':q("SELECT COUNT(*) FROM donations WHERE status='Available'"),'meals_saved':q("SELECT COALESCE(SUM(servings),0) FROM donations WHERE status='Delivered'"),'active_tasks':q("SELECT COUNT(*) FROM tasks WHERE status!='Delivered'"),'ngos':q("SELECT COUNT(*) FROM users WHERE role='ngo' AND verified=1"),'volunteers':q("SELECT COUNT(*) FROM users WHERE role='volunteer' AND verified=1")}
    con.close(); return jsonify(data)

if __name__=='__main__':
    init(); app.run(host='0.0.0.0',port=5000,debug=True)
